<?php
//RIAN EKA PUTRA
//2255201043
// Write your code below:
 echo 11 + 1; 
//Kelas A 
  
  
  


