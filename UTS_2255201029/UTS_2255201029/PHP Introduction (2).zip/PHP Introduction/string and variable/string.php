<?php
//RIAN EKA PUTRA
//2255201043
echo "Hello World!";
//Kelas A
?>
  
  


