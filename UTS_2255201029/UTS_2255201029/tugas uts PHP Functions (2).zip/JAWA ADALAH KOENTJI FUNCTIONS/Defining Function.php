<?php
// Write your code below:
  function praisePHP()
  {
    echo "Hello, People!\n";
  }