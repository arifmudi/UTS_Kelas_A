<?php
//Rian Eka Putra
//2255201043
//Kelas A
namespace Codecademy;

// Write your code below:
echo getrandmax();
echo "\n";
echo rand();
echo "\n";
echo rand(1, 999);