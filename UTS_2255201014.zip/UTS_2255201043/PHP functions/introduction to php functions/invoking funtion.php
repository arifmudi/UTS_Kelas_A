<?php
//Rian Eka Putra
//2255201043
//Kelas A
// Write your code below:
  function inflateEgo()
  {
    echo "Hello, People!\n";
  }

 inflateEgo();
 /*
 Prints:
 Hello, People
 */
 inflateEgo();