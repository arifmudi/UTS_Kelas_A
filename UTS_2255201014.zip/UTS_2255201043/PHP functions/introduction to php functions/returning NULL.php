<?php
//Rian Eka Putra
//2255201043
//Kelas A
// Write your code below:
  function createVacuum()
  {
    echo "I'm groot! I'm groot!\n";
  }

  $result = createVacuum();

  echo $result;

echo createVacuum() * 10;