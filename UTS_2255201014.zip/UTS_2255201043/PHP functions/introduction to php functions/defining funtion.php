<?php
//Rian Eka Putra
//2255201043
//Kelas A
// Write your code below:
function praisePHP()
{
 echo "rian.epe";
}
  
  
  
  
  
  
  
  
  
  
  