<?php
  //Rian Eka Putra
//2255201043
//Kelas A
  include "top_bread.php";
  include "mayo.php";
  include "lettuce.php";
  
  echo "Sliced, ripe tomatoes\nBacon\nTurkey\n";
  
  include "bottom_bread.php";