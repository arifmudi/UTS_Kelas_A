<?php
$fruit = "banana";
$protein = "pork";

// Write your code below:
if ($fruit == "banana" xor $protein == "chicken"){
  echo "Dig in!";
} 