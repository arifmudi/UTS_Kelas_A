<?php
//RIAN EKA PUTRA
//2255201043
// Write your code below:
  
 echo 8 ** 2; 
//Kelas A
  

