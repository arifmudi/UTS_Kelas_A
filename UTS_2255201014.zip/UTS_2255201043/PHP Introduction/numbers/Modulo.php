<?php
//RIAN EKA PUTRA
//2255201043
// Write your code below:
  
 echo 82 % 6; 
 //Kelas A 
  


