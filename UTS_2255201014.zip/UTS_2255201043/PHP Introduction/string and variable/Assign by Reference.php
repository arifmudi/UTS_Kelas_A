<?php
//Rian Eka Putra
//2255201043
/* Imagine a lot of code here */  
  $very_bad_unclear_name = "15 ekor domba";

// Write your code here:
$example = "Halo, Dunia!";
$order =& $very_bad_unclear_name;


    
  // Don't change the line below
  echo "\nYour order is: $very_bad_unclear_name.";

$sentence = "Halo";
$sentence .= ", Dunia";
$sentence .= "!";
 gema $sentence; // Cetakan: Halo, Dunia!
 //Kelas A

