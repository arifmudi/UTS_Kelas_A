<?php
//RIAN EKA PUTRA
//2255201043
echo "1. Teach PHP";
echo "1. Teach PHP";
echo "\n2. Eat breakfast"; 
echo "1. Teach PHP";
echo "\n2. Eat breakfast";
echo "\n3. Learn to have \"fun\""; 
//Kelas A