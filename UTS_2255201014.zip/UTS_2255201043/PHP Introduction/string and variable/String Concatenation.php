<?php
//RIAN EKA PUTRA
//2255201043   
echo "Code" . "cademy";


  //echo "\nMy name is:" 
echo "\nMy name is:" . "rian eka putra"; 
echo "\n" . "tur" . "duck" . "en";
//Kelas A