<?php

//Luthfi Aldrie Rasyid
namespace Codecademy;

$first = "Welcome to the magical world of built-in functions.";

$second = 82137012983;
//2255201044

//Write your code below:

echo gettype($first);

echo gettype($second);

var_dump($first);

var_dump($second);
//Kelas A