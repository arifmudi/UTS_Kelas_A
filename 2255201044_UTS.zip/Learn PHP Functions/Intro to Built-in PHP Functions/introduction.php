<?php
//Luthfi Aldrie Rasyid
echo("This works!\n");

echo "This also works!\n";
//2255201044
//echo("This would NOT work", "\n");

echo "Buuuut!", " ", "This", " ", "does!", "\n";<?php
//Kelas A