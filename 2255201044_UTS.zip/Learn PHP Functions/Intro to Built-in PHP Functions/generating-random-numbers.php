<?php
//Luthfi Aldrie Rasyid
namespace Codecademy;
//2255201044
// Write your code below:
echo getrandmax();
echo "\n";
echo rand();
echo "\n";
echo rand(1, 52);
//Kelas A