<?php
//Luthfi Aldrie Rasyid
namespace Codecademy;

$a = 29;
$b = "You did it!";
$c = STR_PAD_BOTH;
$d = "*~*";
//2255201044
// Write your code below:
echo str_pad($b, $a, $d, $c);
//Kelas A