<?php
//Luthfi Aldrie Rasyid
namespace Codecademy;

// Write your code below:
echo strrev(".pu ti peeK .taerg gniod er'uoY");
//2255201044
echo strtolower("SOON, tHiS WILL Look NoRmAL.");

echo str_repeat("\nThere's no place like home.\n", 3);
//Kelas A
