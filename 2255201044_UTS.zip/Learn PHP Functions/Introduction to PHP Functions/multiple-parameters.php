<?php
//Luthfi Aldrie Rasyid
// Write your code below:
function calculateArea($height, $width)
{
    return $height * $width;
}
//2255201044
function calculateVolume($height, $width, $depth)
{
    return $height * $width * $depth;
}

echo calculateArea(5, 10);
echo "\n";
echo calculateVolume(4, 11, 7);
//Kelas A