<?php
//Luthfi Aldrie Rasyid
$string_one = "you have teeth";
$string_two = "toads are nice";
$string_three = "brown is my favorite color";

// Write your code below:
function convertToQuestion(&$str)
{
    $str = "Do you think " . $str . "?\n";
}
//2255201044
convertToQuestion($string_one);
convertToQuestion($string_two);
convertToQuestion($string_three);

echo $string_one;
echo $string_two;
echo $string_three;
//Kelas A
