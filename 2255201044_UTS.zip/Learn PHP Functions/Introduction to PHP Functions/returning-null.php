<?php
//Luthfi Aldrie Rasyid
// Write your code below:
function createVacuum()
{
    echo "It doesn't actually matter if this function does anything as long as it returns NULL.";
}
//2255201044

echo createVacuum() * 10;
//Kelas A