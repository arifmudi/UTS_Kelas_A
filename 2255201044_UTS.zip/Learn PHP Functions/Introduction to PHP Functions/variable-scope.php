<?php
//Luthfi Aldrie Rasyid
$language = "PHP";
$topic = "scope";
//2255201044
function generateLessonName($concept)
{
    global $language;
    return $language . ": " . $concept;
}

echo generateLessonName($topic);
//Kelas A