<?php
//Luthfi Aldrie Rasyid
function first()
{
    return "You did it!\n";
}

function second()
{
    return "You're amazing!\n";
}
//2255201044
function third()
{
    return "You're a coding hero!\n";
}

// Write your code below:
echo first() . second() . third();
//Kelas A