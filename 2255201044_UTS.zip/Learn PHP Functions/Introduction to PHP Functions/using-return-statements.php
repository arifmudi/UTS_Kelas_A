<?php
//Luthfi Aldrie Rasyid
// Write your code below:

function printStringReturnNumber()
{
    echo "ERROR: Page not found!\n";
    return 404;
}
//2255201044
$my_num = printStringReturnNumber();

echo $my_num;
//Kelas A