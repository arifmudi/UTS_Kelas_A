<?php
//Luthfi Aldrie Rasyid
// Write your code below:

function praisePHP()
//2255201044
{
    echo "PHP is a wonderful language!";

}
//Kelas A