<?php
//Luthfi Aldrie Rasyid
// Write your code below:
function inflateEgo()
//2255201044
{
    echo "u so beautiful\n";
}
inflateEgo();

inflateEgo();
//Kelas A