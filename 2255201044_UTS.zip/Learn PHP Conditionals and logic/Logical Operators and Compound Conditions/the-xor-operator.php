<?php
//Luthfi Aldrie Rasyid
namespace Codecademy;
$fruit = "banana";
$protein = "pork";
//2255201044
// Write your code below:
if ($fruit == "banana" xor $protein == "chicken"){
    echo "Dig in!";
}
//Kelas A