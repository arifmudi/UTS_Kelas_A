<?php
//Luthfi Aldrie Rasyid
include "top_bread.php";
include "mayo.php";
include "lettuce.php";
//2255201044
echo "Sliced, ripe tomatoes\nBacon\nTurkey\n";

include "bottom_bread.php";
//Kelas A