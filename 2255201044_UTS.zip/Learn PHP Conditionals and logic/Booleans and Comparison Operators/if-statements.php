<?php
//Luthfi Aldrie Rasyid
$markAnswer = FALSE
//2255201044
function markAnswer($is_correct)
//Kelas A
