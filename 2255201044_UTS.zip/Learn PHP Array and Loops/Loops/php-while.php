<?php
//Luthfi Aldrie Rasyid
$count = 1;
while ($count <= 100)
{
//2255201044
  if ($count % 33 === 0) {
    echo $count . " is divisible by 33\n";
  }
  $count += 1;
}
//Kelas A