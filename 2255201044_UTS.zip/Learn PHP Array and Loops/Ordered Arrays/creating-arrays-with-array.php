<?php
//Luthfi Aldrie Rasyid
// Write your code below:
$first_array = array("hello", 88, "my", -12361.11, "friend");
//2255201044
echo count($first_array); 
//Kelas A