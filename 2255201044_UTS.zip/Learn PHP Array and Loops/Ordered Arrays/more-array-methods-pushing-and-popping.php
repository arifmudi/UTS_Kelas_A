<?php
//Luthfi Aldrie Rasyid
$stack = ["wild success", "failure", "struggle"];
// Write your code below:
array_push($stack, "blocker","impediment");
//2255201044
print_r($stack);

array_pop($stack);
array_pop($stack);
array_pop($stack);
array_pop($stack);

print_r($stack);
//Kelas A