<?php
//Luthfi Aldrie Rasyid
namespace Codecademy;

// Write your code below:
$with_function = array("PHP", "popcorn", 555.55);
//2255201044
$with_short = ["PHP", "popcorn", 555.55];
//Kelas A