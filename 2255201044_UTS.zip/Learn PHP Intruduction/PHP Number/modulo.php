<?php
//Luthfi Aldrie Rasyid
// Write your code below:
//2255201044
 echo 4 % 8; 
//Kelas A  