<?php
//Luthfi Aldrie Rasyid
// Write your code below:
 $my_num = 12;

	$answer = $my_num;

	$answer += 2;

	$answer *= 2;
//2255201044
	$answer -= 2;

	$answer /= 2;

	$answer -= $my_num;

	echo $answer;
//Kelas A