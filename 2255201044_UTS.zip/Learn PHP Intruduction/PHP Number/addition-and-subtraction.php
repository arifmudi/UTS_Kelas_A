<?php
//Luthfi Aldrie Rasyid
// Write your code below:
//2255201044
 echo 8.2 + 3.8;
//Kelas A  