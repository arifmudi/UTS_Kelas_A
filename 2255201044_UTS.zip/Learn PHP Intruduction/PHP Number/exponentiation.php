<?php
//Luthfi Aldrie Rasyid
// Write your code below:
//2255201044
echo 8 ** 2; 
//Kelas A 