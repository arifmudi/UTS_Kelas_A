<?php
//Luthfi Aldrie Rasyid
// Write your code below:
  $last_month = 1187.23;
//2255201044
  $this_month = 1089.98;

  echo $last_month - $this_month;
//Kelas A