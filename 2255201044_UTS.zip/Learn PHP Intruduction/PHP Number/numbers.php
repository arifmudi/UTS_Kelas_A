<?php
//Luthfi Aldrie Rasyid
// Write your code below:
 $age = 11;

  echo $age;
//2255201044
  echo "\n";

  $movie_rating = 3.2;

  echo $movie_rating;
//Kelas A 