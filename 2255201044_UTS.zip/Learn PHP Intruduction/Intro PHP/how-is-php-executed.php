<?php
//Luthfi Aldrie Rasyid
echo "Hello World";
//2255201044
//Kelas A