<?php
//Luthfi Aldrie Rasyid
// I will always remember this
echo "Hello, World!"; # My first PHP statement
//2255201044
/* "I've never thought of PHP as more 
than a simple tool to solve problems."
- Rasmus Lerdorf */
echo "\nPemula Belajar PHP!";
//Kelas A