<?php
//Luthfi Aldrie Rasyid
// Write your code below:   

//2255201044
//echo "\nMy name is:" 
echo "Code" . "cademy"; 
echo "\nMy name is:" . " Devi Selvi Yanti";
echo "\n" . "tur" . "duck" . "en";
//Kelas A