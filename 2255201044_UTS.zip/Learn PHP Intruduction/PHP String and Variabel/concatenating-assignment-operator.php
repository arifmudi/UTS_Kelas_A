<?php
//Luthfi Aldrie Rasyid
  echo "I'm going on a picnic!";

  $sentence .= ", baring";
  $sentence .= ", cari";
  echo $sentence;

// Write your code below:
//2255201044
$sentence .= ", bananas";
  
   echo $sentence;
   
   $sentence .= ", carrots";

   echo $sentence;
//Kelas A