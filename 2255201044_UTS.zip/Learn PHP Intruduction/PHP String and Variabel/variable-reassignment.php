<?php
//Luthfi Aldrie Rasyid
  $movie = "One Piece";
  $old_favorite = "One Piece 1999";
// Add your code here:

 $movie = "The Matrix";
 $old_favorite = $movie;

  echo "I'm a fickle person, my favorite movie used to be $movie.";
//2255201044
// Add a statement here:
  $movie = "Durara";
  
  echo "\nBut now my favorite is $movie.";
  
// Add a statement below:
 echo "\nBut I'll always have a special place in my heart for $old_favorite.";
//Kelas A