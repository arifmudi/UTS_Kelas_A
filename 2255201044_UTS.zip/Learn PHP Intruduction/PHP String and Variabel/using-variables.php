<?php
//Luthfi Aldrie Rasyid
// Write your code below:
$name = "Devi Selvi Yanti";
$language = "Indonesia"; 
//2255201044
$name = "echo";
echo "I love concatenating " . $name;
 
$language = "echo";
echo "\nI love " . $language;  
//Kelas A