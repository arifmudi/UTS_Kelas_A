<?php
//Luthfi Aldrie Rasyid
// Write your code below:
$shawir = "penggemar One Piece";  
$biography = "\nOne Piece adalah sebuah seri manga Jepang yang ditulis dan diilustrasikan oleh Eiichiro Oda. Manga ini telah dimuat di majalah Weekly Shōnen Jump milik Shueisha sejak tanggal 22 Juli 1997, dan telah dibundel menjadi 105 volume tankōbon hingga Maret 2023.";
//2255201044
$favorite_food = "\n" . "tur" ."duck" . "en";  
//Kelas A