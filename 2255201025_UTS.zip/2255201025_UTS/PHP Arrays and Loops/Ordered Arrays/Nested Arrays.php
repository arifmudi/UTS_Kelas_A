<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

// kelas A


$treasure_hunt = ["garbage", "cat", 99, ["soda can", 8, ":)", "sludge", ["stuff", "lint", ["GOLD!"], "cave", "bat", "scorpion"], "rock"], "glitter", "moonlight", 2.11];
  
// Write your code below:

echo $treasure_hunt[3][4][2][0];