<?php

//Muhammad Syafiq Firdaus Affan
//2255201025

// kelas A
// Write your code below:
$with_function = array("JAVA", "sate", 041204);
$with_short = ["JAVA", "sate", 041204];