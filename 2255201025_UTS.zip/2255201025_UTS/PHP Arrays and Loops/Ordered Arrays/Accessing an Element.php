<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

// kelas A

$round_one = ["X", "X", "first winner"];

$round_two = ["x", "X", "second winner", "X"];

$round_three = ["third winner", "X", "X", "X", "x"];

// Write your code below:
$winners = [$round_one[2], $round_two[2], $round_three[0]];

print_r($winners);