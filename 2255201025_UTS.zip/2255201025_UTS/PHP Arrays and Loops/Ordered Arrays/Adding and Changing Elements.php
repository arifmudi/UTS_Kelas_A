<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

// kelas A

$change_me = [3, 6, 9];
// Write your code below:

$change_me[] = "siuuuuu";

$change_me[] = 77;

$change_me[1] = "slebew";

print_r($change_me);