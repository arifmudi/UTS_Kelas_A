<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

// kelas A
$first_array = array ("first element", 1, "third element", 3, "fourth element");
echo count($first_array); // Prints: 10