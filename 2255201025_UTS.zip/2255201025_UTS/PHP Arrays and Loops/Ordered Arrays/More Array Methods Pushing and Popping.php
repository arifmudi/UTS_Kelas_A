<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

// kelas A

$stack = ["messi", "ronaldo", "neymar"];
// Write your code below:
array_push($stack, "benzema","aciong");

print_r($stack);

array_pop($stack);
array_pop($stack);
array_pop($stack);
array_pop($stack);

print_r($stack);