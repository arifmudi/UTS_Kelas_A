<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

// kelas A

$message = ["Oh hey", " You're doing great", " Keep up the good work!\n"];

$favorite_nums = [4, 57, 35, 24, 245];
// Write your code below:

echo implode("!", $message);
print_r($favorite_nums);