<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

// kelas A
$september_hits = ["The Sixth Sense" => 7777,
"Stigmata" => 22222,
"Blue Streak" => 111111,
"Double Jeopardy" => 666666];

echo implode(", ", $september_hits);

print_r($september_hits);
