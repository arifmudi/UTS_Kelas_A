<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

// kelas A
$hybrid_array = [79, "tai", 99, "kiwkiw"];

$hybrid_array[8] = "prabowo";

print_r($hybrid_array);

array_push($hybrid_array, rand());

echo $hybrid_array[9];