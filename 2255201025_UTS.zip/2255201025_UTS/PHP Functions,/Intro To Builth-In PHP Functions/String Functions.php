<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

echo strrev("Perkenalkan Saya Mahasiswa,\n");

echo strtolower("\nDari Prodi S1 Teknik informatika");

echo str_repeat("\nUniversitas Pahlawan Tuanku Tambusai.\n", 9);
// kelas A