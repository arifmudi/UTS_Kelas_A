<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

$j = 29;
$a = "Aku Jawa dan Aku Bangga!";
$w = STR_PAD_BOTH;
$aa = "*~*";

echo str_pad($a, $j, $aa, $w);
// kelas A