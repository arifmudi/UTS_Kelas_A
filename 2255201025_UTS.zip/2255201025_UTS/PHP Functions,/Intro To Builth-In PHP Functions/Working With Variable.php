<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

$siji = "Perkenalkan saya Mahasiswa dari Universitas Pahlawan Tuanku Tambusai";
  
$loro = 225520101010; 

//Write your code below:

echo gettype($siji);

echo gettype($loro);

var_dump($siji);

var_dump($loro);
// kelas A