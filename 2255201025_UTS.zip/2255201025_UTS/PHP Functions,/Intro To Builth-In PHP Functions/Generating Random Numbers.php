<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

echo getrandmax();
echo "\n";
echo rand();
echo "\n";
echo rand(1, 999);
// kelas A