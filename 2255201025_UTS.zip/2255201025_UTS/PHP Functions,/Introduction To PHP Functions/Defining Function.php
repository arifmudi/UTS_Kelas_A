<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
  function praisePHP()
  {
    echo "Hello, People!\n";
  }
  // kelas A