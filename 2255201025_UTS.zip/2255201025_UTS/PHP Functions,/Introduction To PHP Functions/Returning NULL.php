<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

  function createVacuum()
  {
    echo "I'm groot! I'm groot!\n";
  }

  $result = createVacuum();

  echo $result;

echo createVacuum() * 10;
// kelas A