<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

 function printStringReturnNumber()
 {
  echo "eleven";
  return 11;
 }


 $my_num = printStringReturnNumber();
 echo $my_num = 11;
//  kelas A