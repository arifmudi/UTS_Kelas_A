<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
function first()
{
  return "You did it!\n";
}

function second()
{
  return "You're amazing!\n";
}

function third()
{
  return "You're a coding hero!\n";
}

echo first() . " " . second() . " " . third();
// kelas A