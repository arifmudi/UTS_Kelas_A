<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
  function inflateEgo()
  {
    echo "Hello, People!\n";
  }

 inflateEgo();
 /*
 Prints:
 Hello, People
 */
 inflateEgo();
//  kelas A