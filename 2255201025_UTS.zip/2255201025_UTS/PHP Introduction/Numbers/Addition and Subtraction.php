<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
 echo 11 + 1; 
//Kelas A 
  
  
  


