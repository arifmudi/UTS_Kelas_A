<?php
//Muhammad Syafiq Firdaus Affan
//2255201025

 $my_num = -190.82; 
 $answer = $my_num;
 $answer += 2;
 $answer *= 2;
 $answer -= 2;
 $answer /= 2;
 $answer -= $my_num;
 echo $answer;
 //kelas A 
  
  
  
  
  
  
  
  
  
