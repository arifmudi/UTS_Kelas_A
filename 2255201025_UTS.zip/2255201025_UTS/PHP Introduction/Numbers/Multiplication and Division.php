<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
  
$num_languages = 4;
$months = 11;
$days = 16;
$a = $num_languages / $months *$days;
echo $a;  
 //kelas A 



