<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
 echo 8 ** 2; 
//Kelas A
  

