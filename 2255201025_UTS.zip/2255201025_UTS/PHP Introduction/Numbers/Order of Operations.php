<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
  
echo 94 - 4.25 + 7 - (23.50 + 23.50 * .2) + 20 / 4 ;
//Kelas A  
  


