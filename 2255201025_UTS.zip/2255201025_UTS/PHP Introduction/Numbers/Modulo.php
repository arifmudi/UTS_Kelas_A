<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
  
 echo 82 % 6; 
 //Kelas A 
  


