<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
 $last_month = 1187.23;
echo $last_month; 
  
 $this_month = 1089.98;
echo $this_month;

 $jumlah = $last_month - $this_month;
echo $jumlah;  
 //Kelas A 


