<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
echo "1. Teach PHP";
echo "1. Teach PHP";
echo "\n2. Eat breakfast"; 
echo "1. Teach PHP";
echo "\n2. Eat breakfast";
echo "\n3. Learn to have \"fun\""; 
//Kelas A