<?php
///Muhammad Syafiq Firdaus Affan
//2255201025
  $very_bad_unclear_name = "15 ekor domba";

$example = "Halo, Dunia!";
$order =& $very_bad_unclear_name;


    
echo "\nYour order is: $very_bad_unclear_name.";

$sentence = "Halo";
$sentence .= ", Dunia";
$sentence .= "!";
echo $sentence; // Cetakan: Halo, Dunia!
 //Kelas A

