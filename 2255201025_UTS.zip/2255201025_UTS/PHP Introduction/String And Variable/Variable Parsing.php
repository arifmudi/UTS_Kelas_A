<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
  $noun = "jdngkz";
  $adjective = "blabla";
  $verb = "hdbsjhb";

  echo "The world's most beloved $noun was very $adjective and loved to $verb every single day.";


//Fix the code below and uncomment it:

 echo "\nI have always been obsessed with ${noun}s. I'm ${adjective}ish. I'm always ${verb}ing.";
//Kelas A
