<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
echo "I'm going on a picnic!";

$sentence = "\nI'm going on a picnic, and I'm taking apples";

echo $sentence;

$sentence .= "Halo";
$sentence .= ", Dunia";
$sentence .= "!";
echo $sentence; // Cetakan: Halo, Dunia!
//Kelas A



