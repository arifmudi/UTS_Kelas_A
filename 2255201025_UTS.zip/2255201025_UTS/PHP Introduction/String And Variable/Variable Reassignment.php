<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
  $movie = "lehay";
// Add your code here:
  $movie = "The Matrix";
  $old_favorite = $movie;

  echo "I'm a fickle person, my favorite movie used to be $movie.";
  
// Add a statement here:
  $movie = "Dunkirk";
  
  echo "\nBut now my favorite is $movie.";
  
// Add a statement below:
  echo "\nBut I'll always have a special place in my heart for $old_favorite.";
  //kelas A
  




