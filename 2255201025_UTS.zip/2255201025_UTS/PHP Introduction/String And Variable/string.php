<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
echo "Hello World!";
//Kelas A
?>
  
  


