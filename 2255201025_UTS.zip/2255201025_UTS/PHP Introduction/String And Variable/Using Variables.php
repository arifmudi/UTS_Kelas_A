<?php
//Muhammad Syafiq Firdaus Affan
//2255201025
$name = "Halo, saya variabel!";
$language = "Oh hai. Saya juga variabel.";  
$name = "variabel";
  echo "Saya suka bersambung" . $name;  
$language = "burger";
  echo "\nSaya suka " . $language;
  //kelas A
  


