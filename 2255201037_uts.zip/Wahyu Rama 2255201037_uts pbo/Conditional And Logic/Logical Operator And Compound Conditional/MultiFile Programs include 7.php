<?php
   include "top_bread.php";
 include "mayo.php";
  include "lettuce.php";
   echo "Sliced, ripe tomatoes\nBacon\nTurkey\n";
   include "bottom_bread.php";


   ?>