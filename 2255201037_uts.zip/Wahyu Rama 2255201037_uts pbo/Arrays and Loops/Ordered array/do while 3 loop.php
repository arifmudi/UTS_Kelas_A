<?php
  $plant_height = 22;
$plant_height{
# code block
do {
 echo "Some string and $my_variable go together like PB&J.\n";
} while ( $plant_height);
if (/*condition*/){
# code block
}


?>