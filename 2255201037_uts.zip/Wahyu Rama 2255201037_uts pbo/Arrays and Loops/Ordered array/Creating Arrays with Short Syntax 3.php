<?php
namespace Codecademy;

// Write your code below:
$with_function = array("PHP", "popcorn", 555.55);

$with_short = ["PHP", "popcorn", 555.55];
?>