<?php
namespace Codecademy;

$round_one = ["hallo", "hai", "kamsahamida"];

$round_two = ["buah", "jeruk", "mangga", "stroberry"];

$round_three = ["jawa", "bali", "medan", "jepang", "korea"];

// Write your code below:
$winners = [$round_one[2], $round_two[0], $round_three[4]];

print_r($winners);
?>