<?php
namespace Codecademy;

$change_me = [3, 6, 9];
// Write your code below:
$change_me[] = "woohoo";

$change_me[] = 77;

$change_me[1] = "tadpole";

print_r($change_me);
?>