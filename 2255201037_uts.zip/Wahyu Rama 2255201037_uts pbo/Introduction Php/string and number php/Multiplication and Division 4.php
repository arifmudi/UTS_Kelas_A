<?php
// Write your code below:
 $num_languages = 4;
	$months = 11;

	$days = $months * 16;

	$days_per_language = $days / $num_languages;
	
	echo $days_per_language;

	
  


?>