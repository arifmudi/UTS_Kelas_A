<?php
  
  $my_num = -19273645.862;

	$answer = $my_num;

	$answer += 2;

	$answer *= 2;

	$answer -= 2;

	$answer /= 2;

	$answer -= $my_num;

  echo "Look! It still works!\n";

	echo $answer;

  echo "\nCool?\nIt's a little cool, right?";

  
  


?>