<?php
// Write your code below:
 $last_month = 1187.23;

  $this_month = 1089.98;

  echo $last_month - $this_month;

  
  


?>