<?php
  echo "I'm going on a picnic!";

  $sentence = "\nI'm going on a picnic, and I'm taking apples";

  echo $sentence;

// Write your code below:
$sentence .= ", bola";
  
   echo $sentence;
   
   $sentence .= ", burger";

   echo $sentence;

$sentence .= ", cacing";
  
   echo $sentence;
   
   
?>