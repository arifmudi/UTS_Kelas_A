<?php
// Fill in the blanks in the code below:
   $noun = "jam";
  $adjective = "baik";
  $verb = "masak";

  echo "The world's most beloved $noun was very $adjective and loved to $verb every single day.";


//Fix the code below and uncomment it:

 echo "\nI have always been obsessed with ${noun}s. I'm ${adjective}ish. I'm always ${verb}ing.";



?>