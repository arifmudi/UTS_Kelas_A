<?php
// Write your code below:
  $name = "Hello I am a variable!";
$language = "Oh hi. I'm also a variable.";

  $name = "variables";
echo "I love concatenating " . $name;
  
  $language = "english";
echo "\nI love " . $language;


?>