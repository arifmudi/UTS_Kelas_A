<?php
// Write your code below:

$my_num = 12;

	$answer = $my_num;

	$answer += 2;

	$answer *= 2;

	$answer -= 2;

	$answer /= 2;

	$answer -= $my_num;

	echo $answer;
  
  
?>