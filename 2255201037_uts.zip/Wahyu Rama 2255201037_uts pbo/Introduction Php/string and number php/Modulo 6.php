<?php
// Write your code below:
  
  echo 82 % 6;
  
  
  


?>