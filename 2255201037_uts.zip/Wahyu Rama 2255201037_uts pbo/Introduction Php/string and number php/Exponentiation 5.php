<?php
// Write your code below:
  echo 8 ** 2; 
  
  
  

?>