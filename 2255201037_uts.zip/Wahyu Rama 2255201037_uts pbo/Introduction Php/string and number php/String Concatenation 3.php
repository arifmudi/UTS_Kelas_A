<?php
// Write your code below:   
echo "Code" . "cademy";

echo "\nMy name is:" . " wahyu rama ";

 echo "\n" . "tur" . "duck" . "en";

  
  


?>