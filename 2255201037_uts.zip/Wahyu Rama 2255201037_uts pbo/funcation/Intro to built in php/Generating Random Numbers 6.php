<?php
namespace Codecademy;

echo getrandmax();
echo "\n";
echo rand();
echo "\n";
echo rand(1, 52);

?>