<?php
namespace Codecademy;

$a = 29;
$b = "iam very happy!";
$c = STR_PAD_BOTH;
$d = "*~*";

// Write your code below:
echo str_pad($b, $a, $d, $c);
?>