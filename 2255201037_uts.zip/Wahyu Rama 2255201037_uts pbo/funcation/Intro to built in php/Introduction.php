<?php
echo("This works!\n");

echo "This also works!\n";

//echo("This would NOT work", "\n");

echo "Buuuut!", " ", "This", " ", "does!", "\n";

?>