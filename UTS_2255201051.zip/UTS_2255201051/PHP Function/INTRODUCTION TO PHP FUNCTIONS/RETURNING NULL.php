<?php
//OKTA BERNALDI
//2255201051
//Kelas A
// Write your code below:
  function createVacuum()
  {
    echo "I'm groot! I'm groot!\n";
  }

  $result = createVacuum();

  echo $result;

echo createVacuum() * 10;