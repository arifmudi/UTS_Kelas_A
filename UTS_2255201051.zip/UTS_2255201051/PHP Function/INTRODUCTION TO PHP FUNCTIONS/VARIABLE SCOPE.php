<?php
//OKTA BERNALDI
//2255201051
//Kelas A
$dinosaurus = "Brontosaurus";
$jenis = "Hewan Purba";

function generateLessonName($trex)
{
  global $dinosaurus;
  return $dinosaurus . ": " . $trex;
}

echo generateLessonName($jenis);