<?php
//OKTA BERNALDI
//2255201051
//Kelas A
// Write your code below:
function praisePHP()
{
 echo "okta.bernaldi";
}
  
  
  
  
  
  
  
  
  
  
  