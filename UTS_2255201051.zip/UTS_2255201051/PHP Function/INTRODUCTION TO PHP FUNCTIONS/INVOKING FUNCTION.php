<?php
//OKTA BERNALDI
//2255201051
//Kelas A
// Write your code below:
  function inflateEgo()
  {
    echo "Hello, People!\n";
  }

 inflateEgo();
 /*
 Prints:
 Hello, People
 */
 inflateEgo();