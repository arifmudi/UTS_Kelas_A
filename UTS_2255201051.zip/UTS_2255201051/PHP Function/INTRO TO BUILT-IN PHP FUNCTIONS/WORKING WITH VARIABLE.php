<?php
//OKTA BERNALDI
//2255201051
//Kelas A
namespace Codecademy;

$siji = "Perkenalkan saya Mahasiswa dari Universitas Pahlawan Tuanku Tambusai";
  
$loro = 225520101010; 

//Write your code below:

echo gettype($siji);

echo gettype($loro);

var_dump($siji);

var_dump($loro);