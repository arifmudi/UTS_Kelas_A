<?php
//OKTA BERNALDI
//2255201051
//Kelas A
namespace Codecademy;

// Write your code below:
echo getrandmax();
echo "\n";
echo rand();
echo "\n";
echo rand(1, 999);