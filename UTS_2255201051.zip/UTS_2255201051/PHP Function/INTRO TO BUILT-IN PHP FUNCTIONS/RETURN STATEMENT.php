<?php
//OKTA BERNALDI
//2255201051
//Kelas A
 function printStringReturnNumber()
 {
  echo "eleven";
  return 11;
 }


 $my_num = printStringReturnNumber();
 echo $my_num = 11;