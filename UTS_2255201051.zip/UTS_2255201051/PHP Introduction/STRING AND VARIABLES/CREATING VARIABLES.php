<?php
//OKTA BERNALDI 
//2255201051
//KELAS A
$silly = "tanpa akal sehat, absurd, konyol"; 
$biography = "\nCodecademy adalah perusahaan pendidikan. Tapi tidak satu pun dengan cara yang mungkin Anda pikirkan. Kami berkomitmen untuk memberikan pengalaman belajar terbaik di dalam dan luar, menjadikan Codecademy tempat terbaik bagi tim kami untuk belajar, mengajar, dan menciptakan masa depan pembelajaran online.";  
$favorite_food = "\n" . "tur" . "duck" . "en";



