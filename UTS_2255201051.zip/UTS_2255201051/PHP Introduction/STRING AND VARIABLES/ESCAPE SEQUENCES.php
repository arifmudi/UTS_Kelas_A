<?php
//OKTA BERNALDI
//2255201051
//KELAS A
echo "1. Teach PHP";
echo "1. Teach PHP";
echo "\n2. Eat breakfast"; 
echo "1. Teach PHP";
echo "\n2. Eat breakfast";
echo "\n3. Learn to have \"fun\""; 
