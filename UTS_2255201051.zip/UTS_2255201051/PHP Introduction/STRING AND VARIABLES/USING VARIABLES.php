<?php
//OKTA BERNALDI
//2255201051
//KELAS A
$name = "Halo, saya variabel!";
$language = "Oh hai. Saya juga variabel.";  
$name = "variabel";
  echo "Saya suka bersambung" . $name;  
$language = "burger";
  echo "\nSaya suka " . $language;
  
  


