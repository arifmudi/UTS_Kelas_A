<?php
//OKTA BERNALDI
//2255201051
//KELAS A
  echo "I'm going on a picnic!";

  $sentence = "\nI'm going on a picnic, and I'm taking apples";

  echo $sentence;

$sentence .= "Halo";
$sentence .= ", Dunia";
$sentence .= "!";
 echo $sentence; // Cetakan: Halo, Dunia!




