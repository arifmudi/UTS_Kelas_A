<?php
//OKTA BERNALDI
//2255201051
//KELAS A
echo "Code" . "cademy";


  //echo "\nMy name is:" 
echo "\nMy name is:" . "OKTA BERNALDI"; 
echo "\n" . "tur" . "duck" . "en";
