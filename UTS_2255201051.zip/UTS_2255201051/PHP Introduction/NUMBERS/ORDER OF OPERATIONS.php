<?php
//OKTA BERNALDI
//2255201051
//KELAS A
// Write your code below:
  
echo 94 - 4.25 + 7 - (23.50 + 23.50 * .2) + 20 / 4 ;

  


