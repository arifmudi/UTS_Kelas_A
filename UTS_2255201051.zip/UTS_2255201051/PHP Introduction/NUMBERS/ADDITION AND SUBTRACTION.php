<?php
//OKTA BERNALDI
//2255201051
//KELAS A
// Write your code below:
 echo 11 + 1; 

  
  
  


