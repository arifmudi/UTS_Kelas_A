<?php
//OKTA BERNALDI
//2255201051
//KELAS A
// Write your code below:
  
 echo 8 ** 2; 

  

