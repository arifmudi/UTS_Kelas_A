<?php
//OKTA BERNALDI
//2255201051
//KELAS A
// Write your code below:
  
$num_languages = 4;
$months = 11;
$days = 16;
$a = $num_languages / $months *$days;
echo $a;  
 



