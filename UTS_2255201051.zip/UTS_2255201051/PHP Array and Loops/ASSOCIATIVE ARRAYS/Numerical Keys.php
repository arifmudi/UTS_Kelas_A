<?php
//OKTA BERNALDI
//2255201051
//KELAS A
namespace Codecademy;

// Write your code below:
$hybrid_array = array("first element", "second element","arga","arya");
$hybrid_array[3] =  "empat lagi";

