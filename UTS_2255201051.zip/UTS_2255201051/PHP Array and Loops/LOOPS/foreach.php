<?php
//OKTA BERNALDI
//2255201051
//KELAS A
$scores = [
  "okta" => 99,
  "bagas" => 95,
  "kulek" => 98,
  "apet" => 91,
  "haikal" => 88
];

foreach ($scores as $score) {
  echo "Someone received a score of $score.\n";
}

foreach ($scores as $name => $score) {
  echo "$name received a score of $score.\n";
}
