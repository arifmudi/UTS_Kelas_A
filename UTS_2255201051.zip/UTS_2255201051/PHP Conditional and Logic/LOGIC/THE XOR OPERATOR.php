<?php
//OKTA BERNALDI
//2255201051
//KELAS A

$fruit = "banana";
$protein = "pork";

// Write your code below:
if ($fruit == "banana" xor $protein == "chicken"){
  echo "Dig in!";
} 