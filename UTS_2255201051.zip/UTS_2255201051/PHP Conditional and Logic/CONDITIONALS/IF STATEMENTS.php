<?php
namespace Codecademy;
//OKTA BERNALDI
//225201051
//KELAS A
function markAnswer($is_correct)
{
  if ($is_correct) {
    return "green";
  } else {
    return "red";
  }
}
echo markAnswer(FLASE);
echo "\n\n";
echo markAnswer(TRUE);
echo "\n\n";

